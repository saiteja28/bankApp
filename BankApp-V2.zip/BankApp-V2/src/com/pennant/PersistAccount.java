package com.pennant;
/*this class is to write data to details.txt file*/
import java.io.IOException;

public class PersistAccount {

	public static void main(String[] args) throws ClassNotFoundException, IOException {
		Customer.writebank();
	}

}

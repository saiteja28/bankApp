package com.pennant;

import java.io.IOException;

public class App {

	public static void main(String[] args) throws ClassNotFoundException, IOException {

		ReadCustomerData.deseri();
		ReadCustomerData.display();
	}

}

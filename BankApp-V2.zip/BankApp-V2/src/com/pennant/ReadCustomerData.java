package com.pennant;
/*
 * this class is to read data from the file
 */

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.List;
import java.util.ListIterator;
import java.util.Scanner;

public class ReadCustomerData {
	static List<PennantBank> banks = null;
	static Scanner sc = new Scanner(System.in);
	static PennantBank pp;
	@SuppressWarnings("unchecked")
	public static void deseri() throws IOException, ClassNotFoundException {
		try {
			FileInputStream f = new FileInputStream("./details.txt");
			ObjectInputStream o = new ObjectInputStream(f);

			banks = (List<PennantBank>) o.readObject();

			f.close();
			o.close();
		} catch (FileNotFoundException f) {
			f.printStackTrace();
		}
	}

	public static void display() {
		System.out.println("Enter your Acc number: ");
		long x = sc.nextLong();
		
		ListIterator<PennantBank> lit = banks.listIterator();
		while(lit.hasNext()){
			
			if(lit.next().getAccno()==x){
				lit.previous();
				System.out.println("Customer name: "+lit.next().getCustomerName());
				lit.previous();
				System.out.println("Address: "+lit.next().getAddress());
				lit.previous();
				System.out.println("Account no: "+lit.next().getAccno());
				lit.previous();
				System.out.println("Balance: "+lit.next().getBalance());
			}
		}
		}
	
}


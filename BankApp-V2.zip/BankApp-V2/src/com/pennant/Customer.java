package com.pennant;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Customer {

	static Scanner s = null;
	static double deposit;
	static PennantBank pb = new PennantBank();

	public static void display() {
		s = new Scanner(System.in);
		try {
			pb.openAccount();
			System.out.println("Choose Your Transaction \n 1.Deposit  ");
			int dw = s.nextInt();
			if (dw == 1) {
				System.out.println("Enter amount to deposit");
				deposit = s.nextDouble();
				pb.deposit(deposit);
			} else if (dw != 1) {
				System.out.println("Thank You visit again!!");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static void writebank() throws IOException, ClassNotFoundException {
		
		List<PennantBank> al=new ArrayList<PennantBank>();
		display();
		pb.setCustomerName(pb.getCustomerName());
		pb.setAccountType(pb.getAccountType());
		pb.setAddress(pb.getAddress());
		pb.setAccno(pb.getAccno());
		pb.setBalance(pb.getBalance());
		File file = new File("./details.txt");
		if(file.exists()){
		ReadCustomerData.deseri();
		al.addAll(ReadCustomerData.banks);
		}
		FileOutputStream fos=new FileOutputStream(file);
		ObjectOutputStream oos=new ObjectOutputStream(fos);
		al.add(pb);
		
		oos.writeObject(al);
		oos.close();
	}

}

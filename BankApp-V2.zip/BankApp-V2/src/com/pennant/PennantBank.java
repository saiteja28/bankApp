package com.pennant;

import java.io.Serializable;
import java.util.Random;
import java.util.Scanner;

public class PennantBank implements Account, Serializable {

	private static final long serialVersionUID = 1L;

	public static final String IFSC = "KT00001944";
	private long accno;
	private double balance;
	private String customerName;
	private String address;
	
	private String accountType;

	transient Scanner s = new Scanner(System.in);

	@Override
	public void deposit(double amount) {
		this.balance = amount;
		System.out.println("Amount deposited: " + "Rs " + amount + " /-");
		System.out.println("Do you want to continue \n 1.WithDraw \n 2.Balance Enquiry ");
		int w = s.nextInt();
		if (w == 1) {
			withDrawal(balance);
		} else if (w == 2) {
			System.out.println("Balance is: " + getBalance());
			checkBalance(balance);

		} else {
			System.out.println("Thank You Visit Again!!");

		}
	}

	@Override
	public void withDrawal(double amt) {
		System.out.println("Enter amount to withdraw");
		double amount = s.nextDouble();
		if (getBalance() >= amount) {
			System.out.println(amount + " rs withdrawn from " + getAccno());
			this.balance = balance - amount;
			System.out.println("Remaining Balance: " + balance);
			checkBalance(balance);
		} else {
			System.err.println("Insufficient balance");
		}
	}

	@Override
	public void openAccount() {
		System.out.println("WELCOME TO PENNANT INTERNATIONAL BANK");
		System.out.println("------------------------------------------");
		System.out.println("Enter Your Name :");
		String name = s.nextLine();
		setCustomerName(name);
		System.out.println("Enter your address: ");
		String addr = s.nextLine();
		setAddress(addr);
		System.out.println("choose your account type\n 1.Current \n 2.Savings");
		int i = s.nextInt();
		if (i == 1) {
			Random random = new Random();
			accno = random.nextInt(1234567890);
			System.out.println("Your account type is Current");
			System.out.println("Your account no is: " + accno + " IFSC code is: " + IFSC);
			setAccountType("Current");
		} else if (i == 2) {
			Random random = new Random();
			accno = random.nextInt(1234567890);
			System.out.println("Your account type is Savings");
			System.out.println("Your account no is: " + accno + " IFSC code is: " + IFSC);
			setAccountType("Savings");
		} else {
			openAccount();
		}
	}

	public long getAccno() {
		return accno;
	}

	public void setAccno(long accno) {
		this.accno = accno;
	}

	@Override
	public void closeAccount() {
		System.out.println("Your account is closed");
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	@Override
	public void checkBalance(double amount) {
		System.out.println("Do you want to continue \n 1.WithDraw \n 2.Balance Enquiry ");
		int i = s.nextInt();
		if (i == 1) {
			withDrawal(amount);
		} else if (i == 2) {
			checkBalance(balance);
		} else {
			System.err.println("Next customers are waiting.. now dont ask me to continue the transactions");
			System.err.println("Thank You Visit Again!!!");
		}

	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getAccountType() {
		return accountType;
	}

	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}

}

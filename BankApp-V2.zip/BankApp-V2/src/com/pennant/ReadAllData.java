package com.pennant;

/*this class is to read all the data from a file*/


import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.ArrayList;
import java.util.List;

public class ReadAllData {

	private static List<PennantBank> banks=null;
	static List<Long> list = new ArrayList<>();
	@SuppressWarnings("unchecked")
	public static void main(String[] args) throws IOException, ClassNotFoundException {
		
		try{
			
		FileInputStream f = new FileInputStream("./details.txt");
		ObjectInputStream o = new ObjectInputStream(f);

		banks = (List<PennantBank>) o.readObject();
		
		
		for(PennantBank pp:banks){
			System.out.println("Customer Name: "+pp.getCustomerName());
			System.out.println("Address: "+pp.getAddress());
			System.out.println("Account Type: "+pp.getAccountType());
			System.out.println("Account no: "+pp.getAccno());
			System.out.println("Balance: "+pp.getBalance());
			System.out.println("------------------------------");
			list.add(pp.getAccno());
			
		}
		System.out.println(list);
		f.close();
		o.close();
		}catch (FileNotFoundException fnf) {
			fnf.printStackTrace();
		}
	}

}//[483622623, 321980231, 1159112889, 506424425]


package com.pennant;

public interface Account {
	
	
	void deposit(double amount);
	void withDrawal(double amount);
	void openAccount();
	void closeAccount();
	void checkBalance(double amount);
	
}
